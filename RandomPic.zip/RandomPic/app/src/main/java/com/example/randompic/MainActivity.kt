package com.example.randompic

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { App() } } }
    }
}

private fun collectImages(dir: DocumentFile, out: MutableList<DocumentFile>) {
    for (f in dir.listFiles()) {
        if (f.isDirectory) collectImages(f, out)
        else if (f.type?.startsWith("image/") == true) out.add(f)
    }
}

private fun copyTo(ctx: Context, src: DocumentFile, destTree: Uri): Boolean = try {
    val dest = DocumentFile.fromTreeUri(ctx, destTree)!!
    val name = src.name ?: "image_${System.currentTimeMillis()}.jpg"
    val out = dest.createFile(src.type ?: "image/jpeg", name.substringBeforeLast('.'))!!
    ctx.contentResolver.openInputStream(src.uri)!!.use { i ->
        ctx.contentResolver.openOutputStream(out.uri)!!.use { o -> i.copyTo(o) }
    }
    true
} catch (e: Exception) { false }

@Composable
fun App() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE) }
    var source by remember { mutableStateOf(prefs.getString("src", null)?.let(Uri::parse)) }
    var dest by remember { mutableStateOf(prefs.getString("dst", null)?.let(Uri::parse)) }
    var images by remember { mutableStateOf<List<DocumentFile>>(emptyList()) }
    var current by remember { mutableStateOf<DocumentFile?>(null) }

    fun persist(uri: Uri) = ctx.contentResolver.takePersistableUriPermission(
        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
    )

    val pickSource = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) {
        it?.let { persist(it); prefs.edit().putString("src", it.toString()).apply(); source = it }
    }
    val pickDest = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) {
        it?.let { persist(it); prefs.edit().putString("dst", it.toString()).apply(); dest = it }
    }

    LaunchedEffect(source) {
        val s = source ?: return@LaunchedEffect
        images = withContext(Dispatchers.IO) {
            val list = mutableListOf<DocumentFile>()
            try { DocumentFile.fromTreeUri(ctx, s)?.let { collectImages(it, list) } } catch (_: Exception) {}
            list
        }
        current = images.randomOrNull()
    }

    Column(
        Modifier.fillMaxSize().padding(16.dp).systemBarsPadding(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { pickSource.launch(null) }) { Text("Source folder") }
            OutlinedButton(onClick = { pickDest.launch(null) }) { Text("Target folder") }
        }
        Spacer(Modifier.height(12.dp))
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            val c = current
            if (c != null) {
                AsyncImage(c.uri, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            } else {
                Text(if (source == null) "Pick a source folder to start" else "No images found")
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { current = images.randomOrNull() }, enabled = images.isNotEmpty()) {
                Text("Next random")
            }
            Button(
                enabled = current != null,
                onClick = {
                    val d = dest
                    if (d == null) {
                        Toast.makeText(ctx, "Pick a target folder first", Toast.LENGTH_SHORT).show()
                    } else {
                        val ok = copyTo(ctx, current!!, d)
                        Toast.makeText(ctx, if (ok) "Added!" else "Copy failed", Toast.LENGTH_SHORT).show()
                    }
                }
            ) { Text("Add to folder") }
        }
    }
}
