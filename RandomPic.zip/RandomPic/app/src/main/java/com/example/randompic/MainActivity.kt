package com.example.randompic

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import coil.compose.AsyncImage
import coil.imageLoader
import coil.request.ImageRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

data class Pic(val uri: Uri, val mime: String, val docId: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            IosTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { App() }
            }
        }
    }
}

@Composable
fun IosTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme()) darkColorScheme(
        primary = Color(0xFF0A84FF), background = Color(0xFF000000), surface = Color(0xFF1C1C1E),
        onSurface = Color.White, onBackground = Color.White, error = Color(0xFFFF453A),
        onSurfaceVariant = Color(0xFF8E8E93), outlineVariant = Color(0xFF38383A)
    ) else lightColorScheme(
        primary = Color(0xFF007AFF), background = Color(0xFFF2F2F7), surface = Color.White,
        onSurface = Color.Black, onBackground = Color.Black, error = Color(0xFFFF3B30),
        onSurfaceVariant = Color(0xFF8E8E93), outlineVariant = Color(0xFFD1D1D6)
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

// ---------- fast file helpers ----------

private fun listImages(ctx: Context, tree: Uri): List<Pic> {
    val out = ArrayList<Pic>()
    val D = DocumentsContract.Document
    fun walk(parentId: String) {
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId)
        ctx.contentResolver.query(
            children, arrayOf(D.COLUMN_DOCUMENT_ID, D.COLUMN_MIME_TYPE, D.COLUMN_DISPLAY_NAME), null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0)
                val mime = c.getString(1) ?: ""
                val name = c.getString(2) ?: ""
                if (mime == D.MIME_TYPE_DIR) {
                    if (!name.startsWith(".") && name != TRASH_DIR) walk(id)
                } else if (mime.startsWith("image/") && !name.startsWith(".")) {
                    out.add(Pic(DocumentsContract.buildDocumentUriUsingTree(tree, id), mime, id))
                }
            }
        }
    }
    try { walk(DocumentsContract.getTreeDocumentId(tree)) } catch (_: Exception) {}
    return out
}

private const val TRASH_DIR = "RandomPic Trash"

private fun copyTo(ctx: Context, src: Pic, dest: DocumentFile): Boolean = try {
    val name = src.docId.substringAfterLast('/').substringBeforeLast('.')
    val out = dest.createFile(src.mime, name)!!
    ctx.contentResolver.openInputStream(src.uri)!!.use { i ->
        ctx.contentResolver.openOutputStream(out.uri)!!.use { o -> i.copyTo(o) }
    }
    true
} catch (e: Exception) { false }

private fun folderName(ctx: Context, u: Uri?): String =
    u?.let { try { DocumentFile.fromTreeUri(ctx, it)?.name } catch (e: Exception) { null } } ?: "Not set"

private fun picRequest(ctx: Context, p: Pic) = ImageRequest.Builder(ctx).data(p.uri).size(1600).build()

// ---------- iOS-style building blocks ----------

@Composable
fun IosButton(
    text: String, onClick: () -> Unit, modifier: Modifier = Modifier,
    enabled: Boolean = true, filled: Boolean = false,
    color: Color = MaterialTheme.colorScheme.primary
) {
    Surface(
        onClick = onClick, enabled = enabled,
        modifier = modifier.height(52.dp).alpha(if (enabled) 1f else 0.4f),
        shape = RoundedCornerShape(14.dp),
        color = if (filled) color else color.copy(alpha = 0.15f),
        contentColor = if (filled) Color.White else color
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun FolderRow(label: String, value: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 17.sp)
        Spacer(Modifier.weight(1f))
        Text(
            value, fontSize = 17.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 200.dp)
        )
        Text("  ›", fontSize = 20.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun SheetRow(text: String, color: Color, bold: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 17.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = color, fontSize = 20.sp, fontWeight = if (bold) FontWeight.SemiBold else FontWeight.Normal)
    }
}

// ---------- app ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    val prefs = remember { ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE) }
    val granted = remember { ctx.contentResolver.persistedUriPermissions.map { it.uri.toString() }.toSet() }
    fun saved(key: String): Uri? = prefs.getString(key, null)?.takeIf { it in granted }?.let(Uri::parse)

    var source by remember { mutableStateOf(saved("src")) }
    var dest by remember { mutableStateOf(saved("dst")) }
    var images by remember { mutableStateOf<List<Pic>>(emptyList()) }
    var current by remember { mutableStateOf<Pic?>(null) }
    var upcoming by remember { mutableStateOf<Pic?>(null) }
    var seen by remember { mutableStateOf<Set<String>>(emptySet()) }
    var loading by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    fun persist(uri: Uri) = ctx.contentResolver.takePersistableUriPermission(
        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
    )

    fun prefetch(p: Pic?) { if (p != null) ctx.imageLoader.enqueue(picRequest(ctx, p)) }

    fun showNext(list: List<Pic>, seenNow: Set<String>) {
        val up = upcoming
        val pick = if (up != null && up.uri.toString() !in seenNow && up in list) up
                   else list.filter { it.uri.toString() !in seenNow }.randomOrNull()
        current = pick
        if (pick != null) {
            val u = pick.uri.toString()
            val newSeen = seenNow + u
            seen = newSeen
            prefs.edit().putStringSet("seen_$source", newSeen).putString("last_$source", u)
                .putString("lastmime_$source", pick.mime).putString("lastid_$source", pick.docId).apply()
            upcoming = list.filter { it.uri.toString() !in newSeen }.randomOrNull()
            prefetch(upcoming)
        } else upcoming = null
    }

    val pickSource = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) {
        it?.let { persist(it); prefs.edit().putString("src", it.toString()).apply(); source = it }
    }
    val pickDest = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) {
        it?.let { persist(it); prefs.edit().putString("dst", it.toString()).apply(); dest = it }
    }

    LaunchedEffect(source) {
        val s = source ?: return@LaunchedEffect
        val seenNow = prefs.getStringSet("seen_$s", emptySet())!!.toSet()
        seen = seenNow
        val last = prefs.getString("last_$s", null)
        if (last != null) { // show the last picture instantly, before the folder is even scanned
            current = Pic(
                Uri.parse(last), prefs.getString("lastmime_$s", "image/jpeg")!!, prefs.getString("lastid_$s", "")!!
            )
        }
        loading = true
        val list = withContext(Dispatchers.IO) { listImages(ctx, s) }
        images = list
        loading = false
        val lastPic = list.firstOrNull { it.uri.toString() == last }
        if (lastPic != null) {
            current = lastPic
            upcoming = list.filter { it.uri.toString() !in seenNow }.randomOrNull()
            prefetch(upcoming)
        } else showNext(list, seenNow)
    }

    fun removeCurrent(c: Pic) {
        images = images.filter { it.uri != c.uri }
        if (current?.uri == c.uri) showNext(images, seen)
    }

    fun toast(msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

    // Samsung's own "Recently deleted" can't be written to by other apps, so the trash is a
    // normal folder inside the source folder. It shows up as an album in the gallery.
    fun moveToTrash() {
        val c = current ?: return
        val s = source ?: return
        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val root = DocumentFile.fromTreeUri(ctx, s)!!
                    val trash = root.findFile(TRASH_DIR) ?: root.createDirectory(TRASH_DIR)!!
                    copyTo(ctx, c, trash) && DocumentsContract.deleteDocument(ctx.contentResolver, c.uri)
                } catch (e: Exception) { false }
            }
            if (ok) { removeCurrent(c); toast("Moved to “$TRASH_DIR” folder") } else toast("Couldn't move to trash")
        }
    }

    val remaining = remember(images, seen) { images.count { it.uri.toString() !in seen } }

    if (confirmDelete) {
        ModalBottomSheet(
            onDismissRequest = { confirmDelete = false },
            containerColor = Color.Transparent, dragHandle = null
        ) {
            Column(
                Modifier.padding(horizontal = 8.dp).navigationBarsPadding().padding(bottom = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(shape = RoundedCornerShape(14.dp), color = cs.surface) {
                    Column {
                        Text(
                            "Delete this picture?", fontSize = 13.sp, color = cs.onSurfaceVariant,
                            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(14.dp)
                        )
                        HorizontalDivider(thickness = 0.5.dp, color = cs.outlineVariant)
                        SheetRow("Move to trash", cs.error) { confirmDelete = false; moveToTrash() }
                    }
                }
                Surface(shape = RoundedCornerShape(14.dp), color = cs.surface) {
                    SheetRow("Cancel", cs.primary, bold = true) { confirmDelete = false }
                }
            }
        }
    }

    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 16.dp)
    ) {
        Text("Random Pic", fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
        Text(
            if (images.isNotEmpty()) "$remaining of ${images.size} left" else " ",
            fontSize = 15.sp, color = cs.onSurfaceVariant
        )
        Spacer(Modifier.height(12.dp))

        Surface(shape = RoundedCornerShape(14.dp), color = cs.surface) {
            Column {
                FolderRow("From", folderName(ctx, source)) { pickSource.launch(null) }
                HorizontalDivider(Modifier.padding(start = 16.dp), thickness = 0.5.dp, color = cs.outlineVariant)
                FolderRow("To", folderName(ctx, dest)) { pickDest.launch(null) }
            }
        }
        Spacer(Modifier.height(12.dp))

        Surface(
            shape = RoundedCornerShape(20.dp), color = cs.surface,
            modifier = Modifier.weight(1f).fillMaxWidth()
        ) {
            Box(
                Modifier.fillMaxSize().pointerInput(Unit) {
                    var total = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { total = 0f },
                        onDragEnd = {
                            if (abs(total) > 120f && images.any { it.uri.toString() !in seen }) {
                                showNext(images, seen)
                            }
                        }
                    ) { _, dx -> total += dx }
                },
                contentAlignment = Alignment.Center
            ) {
                val c = current
                if (c != null) {
                    AsyncImage(
                        model = remember(c) { picRequest(ctx, c) }, contentDescription = null,
                        modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit
                    )
                } else when {
                    source == null -> Text("Choose a “From” folder to start", color = cs.onSurfaceVariant)
                    loading -> CircularProgressIndicator()
                    images.isEmpty() -> Text("No pictures found", color = cs.onSurfaceVariant)
                    else -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("You've seen every picture", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(12.dp))
                        IosButton("Start over", onClick = {
                            seen = emptySet(); upcoming = null
                            prefs.edit().remove("seen_$source").remove("last_$source").apply()
                            showNext(images, emptySet())
                        }, modifier = Modifier.width(160.dp), filled = true)
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))

        IosButton(
            "Next random", onClick = {
                showNext(images, seen)
            },
            modifier = Modifier.fillMaxWidth(), enabled = remaining > 0, filled = true
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            IosButton("Add to folder", onClick = {
                val d = dest
                val c = current
                if (d == null) toast("Choose a “To” folder first")
                else if (c != null) scope.launch {
                    val ok = withContext(Dispatchers.IO) {
                        try { copyTo(ctx, c, DocumentFile.fromTreeUri(ctx, d)!!) } catch (e: Exception) { false }
                    }
                    toast(if (ok) "Added!" else "Copy failed")
                }
            }, modifier = Modifier.weight(1f), enabled = current != null)
            IosButton(
                "Delete", onClick = { confirmDelete = true },
                modifier = Modifier.weight(1f), enabled = current != null, color = cs.error
            )
        }
        Spacer(Modifier.height(12.dp))
    }
}
