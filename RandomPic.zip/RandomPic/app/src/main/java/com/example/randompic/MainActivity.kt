package com.example.randompic

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { App() } } }
    }
}

private fun collectImages(dir: DocumentFile, out: MutableList<DocumentFile>) {
    for (f in dir.listFiles()) {
        if (f.isDirectory) collectImages(f, out)
        else if (f.type?.startsWith("image/") == true) out.add(f)
    }
}

private fun copyTo(ctx: Context, src: DocumentFile, destTree: Uri): Boolean = try {
    val dest = DocumentFile.fromTreeUri(ctx, destTree)!!
    val name = src.name ?: "image_${System.currentTimeMillis()}.jpg"
    val out = dest.createFile(src.type ?: "image/jpeg", name.substringBeforeLast('.'))!!
    ctx.contentResolver.openInputStream(src.uri)!!.use { i ->
        ctx.contentResolver.openOutputStream(out.uri)!!.use { o -> i.copyTo(o) }
    }
    true
} catch (e: Exception) { false }

@Composable
fun App() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE) }
    val granted = remember { ctx.contentResolver.persistedUriPermissions.map { it.uri.toString() }.toSet() }
    fun saved(key: String): Uri? = prefs.getString(key, null)?.takeIf { it in granted }?.let(Uri::parse)

    var source by remember { mutableStateOf(saved("src")) }
    var dest by remember { mutableStateOf(saved("dst")) }
    var images by remember { mutableStateOf<List<DocumentFile>>(emptyList()) }
    var current by remember { mutableStateOf<DocumentFile?>(null) }
    var seen by remember { mutableStateOf<Set<String>>(emptySet()) }
    var loading by remember { mutableStateOf(false) }

    fun persist(uri: Uri) = ctx.contentResolver.takePersistableUriPermission(
        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
    )

    fun showNext(list: List<DocumentFile>, seenNow: Set<String>) {
        val pick = list.filter { it.uri.toString() !in seenNow }.randomOrNull()
        current = pick
        if (pick != null) {
            val u = pick.uri.toString()
            seen = seenNow + u
            prefs.edit().putStringSet("seen_$source", seen).putString("last_$source", u).apply()
        }
    }

    val pickSource = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) {
        it?.let { persist(it); prefs.edit().putString("src", it.toString()).apply(); source = it }
    }
    val pickDest = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) {
        it?.let { persist(it); prefs.edit().putString("dst", it.toString()).apply(); dest = it }
    }

    LaunchedEffect(source) {
        val s = source ?: return@LaunchedEffect
        loading = true
        val list = withContext(Dispatchers.IO) {
            val l = mutableListOf<DocumentFile>()
            try { DocumentFile.fromTreeUri(ctx, s)?.let { collectImages(it, l) } } catch (_: Exception) {}
            l
        }
        images = list
        loading = false
        val seenNow = prefs.getStringSet("seen_$s", emptySet())!!.toSet()
        seen = seenNow
        val last = prefs.getString("last_$s", null)
        val lastFile = list.firstOrNull { it.uri.toString() == last }
        if (lastFile != null) current = lastFile else showNext(list, seenNow)
    }

    val remaining = images.count { it.uri.toString() !in seen }
    fun folderName(u: Uri?) = u?.let { DocumentFile.fromTreeUri(ctx, it)?.name } ?: "not set"

    Column(
        Modifier.fillMaxSize().padding(16.dp).systemBarsPadding(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { pickSource.launch(null) }) {
                Text("From: ${folderName(source)}", maxLines = 1)
            }
            OutlinedButton(onClick = { pickDest.launch(null) }) {
                Text("To: ${folderName(dest)}", maxLines = 1)
            }
        }
        Spacer(Modifier.height(8.dp))
        if (images.isNotEmpty()) Text("$remaining of ${images.size} not shown yet")
        Spacer(Modifier.height(8.dp))
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            val c = current
            if (c != null) {
                AsyncImage(c.uri, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            } else when {
                source == null -> Text("Pick a source folder to start")
                loading -> CircularProgressIndicator()
                images.isEmpty() -> Text("No images found")
                else -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("You've seen every picture!")
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = {
                        seen = emptySet()
                        prefs.edit().remove("seen_$source").remove("last_$source").apply()
                        showNext(images, emptySet())
                    }) { Text("Start over") }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { showNext(images, seen) }, enabled = remaining > 0) { Text("Next random") }
            Button(
                enabled = current != null,
                onClick = {
                    val d = dest
                    if (d == null) {
                        Toast.makeText(ctx, "Pick a target folder first", Toast.LENGTH_SHORT).show()
                    } else {
                        val ok = copyTo(ctx, current!!, d)
                        Toast.makeText(ctx, if (ok) "Added!" else "Copy failed", Toast.LENGTH_SHORT).show()
                    }
                }
            ) { Text("Add to folder") }
        }
    }
}
